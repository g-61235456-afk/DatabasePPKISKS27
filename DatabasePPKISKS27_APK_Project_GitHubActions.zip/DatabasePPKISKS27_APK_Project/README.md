# DatabasePPKISKS27 Android project

## Build APK automatically with GitHub Actions

1. Create a GitHub repository (recommended name: `DatabasePPKISKS27`).
2. Upload the contents of this project to the repository root, including the `.github/workflows/build-apk.yml` file.
3. On GitHub, open **Actions** → **Build DatabasePPKISKS27 APK**.
4. Select **Run workflow** (or push/commit to `main` or `master` to trigger automatically).
5. Wait for the build to finish with a green check mark.
6. Open the successful workflow run. Under **Artifacts**, download `DatabasePPKISKS27-debug-apk`.
7. Extract the artifact ZIP; inside is `app-debug.apk`. Transfer it to your Android phone and install.

## Build locally (Android Studio)
1. Install Android Studio and Android SDK (Android 15 / API 35 platform).
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

The app loads the bundled HTML locally. Student and class records use WebView local storage on the phone. Backup/export records regularly. App backup is disabled to avoid accidental cloud backup of sensitive student records.
